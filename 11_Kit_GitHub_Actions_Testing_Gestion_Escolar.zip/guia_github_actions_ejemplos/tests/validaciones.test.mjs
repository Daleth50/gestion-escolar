import test from 'node:test';
import assert from 'node:assert/strict';
import { validarAlumno, calcularTotalAlumnos } from '../src/lib/validaciones.mjs';

test('un alumno valido no produce errores', () => {
  assert.deepEqual(validarAlumno({ matricula: 'A001', nombre: 'Ana', correo: 'ana@escuela.mx' }), {});
});

test('rechaza matricula vacia', () => {
  const errores = validarAlumno({ matricula: ' ', nombre: 'Ana', correo: 'ana@escuela.mx' });
  assert.equal(errores.matricula, 'La matricula es obligatoria');
});

test('rechaza correo invalido', () => {
  const errores = validarAlumno({ matricula: 'A001', nombre: 'Ana', correo: 'incorrecto' });
  assert.equal(errores.correo, 'El correo no es valido');
});

test('cuenta los alumnos registrados', () => {
  assert.equal(calcularTotalAlumnos([{ id: 1 }, { id: 2 }]), 2);
});
