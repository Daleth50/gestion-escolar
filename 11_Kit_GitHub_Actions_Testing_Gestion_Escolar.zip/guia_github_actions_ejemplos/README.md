# Archivos de ejemplo para la guía GitHub Actions

Copiar al repositorio individual, conservando las rutas relativas:

- `.github/workflows/ci.yml`: pipeline para frontend Next.js ubicado en la raíz.
- `.github/workflows/ci-fullstack.yml`: **alternativa**, solo cuando exista `backend/` con lockfile y script `test:ci`.
- `src/lib/validaciones.mjs`: lógica de ejemplo para validar alumnos.
- `tests/validaciones.test.mjs`: cuatro pruebas automatizadas con `node:test`.

Agregar en `package.json` el script `"test:ci": "node --test tests/*.test.mjs"`.

No activar simultáneamente ambos workflows salvo que se busque deliberadamente ejecutar comprobaciones duplicadas. Ver la guía completa para instrucciones y limitaciones.
